import { Given, Then } from 'cypress-cucumber-preprocessor/steps';

Given('I make a GET request to {string}', (url) => {
  cy.request('GET', url).as('getResponse');
});

Then('the response status code should be {int}', (statusCode) => {
  cy.get('@getResponse').its('status').should('equal', statusCode);
});

Then('the response body should contain user data', () => {
  cy.get('@getResponse').its('body').then((responseBody) => {
    expect(responseBody.data).to.be.an('array').and.not.to.be.empty;
    responseBody.data.forEach((user) => {
      expect(user).to.have.all.keys('id', 'email', 'first_name', 'last_name', 'avatar');
    });
  });
});
