// cypress/support/step_definitions/fetch_user_data_by_id_steps.js

import { Given, Then } from 'cypress-cucumber-preprocessor/steps';

Given('I make a GET request to {string}', (url) => {
  cy.request('GET', url).as('getResponse');
});

Then('the response status code should be {int}', (statusCode) => {
  cy.get('@getResponse').its('status').should('equal', statusCode);
});

Then('the response body should contain the following properties:', (dataTable) => {
  const expectedProperties = dataTable.hashes();
  cy.get('@getResponse').its('body').then((responseBody) => {
    expectedProperties.forEach((property) => {
      const { key, value } = property;
      expect(responseBody).to.have.property(key, value);
    });
  });
});
