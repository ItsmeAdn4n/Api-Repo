import { Given, Then } from 'cypress-cucumber-preprocessor/steps';

Given('I make a GET request to {string}', (url) => {
  cy.request('GET', url).as('getResponse');
});

Then('the response status code should be {int}', (statusCode) => {
  cy.get('@getResponse').its('status').should('equal', statusCode);
});

Then('the response body should contain user data for ID {int}', (userId) => {
  cy.get('@getResponse').its('body').then((responseBody) => {
    expect(responseBody.data).to.have.property('id', userId);
    expect(responseBody.data).to.have.property('email');
    expect(responseBody.data).to.have.property('first_name');
    expect(responseBody.data).to.have.property('last_name');
    expect(responseBody.data).to.have.property('avatar');
  });
});
