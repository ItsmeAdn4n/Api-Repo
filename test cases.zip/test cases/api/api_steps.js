import { Given, Then } from 'cypress-cucumber-preprocessor/steps';

Given('I make a GET request to {string}', (url) => {
  cy.request('GET', url).as('getResponse');
});

Then('the response status code should be {int}', (statusCode) => {
  cy.get('@getResponse').its('status').should('eq', statusCode);
});

Then('the response body should contain the following properties:', (dataTable) => {
  const expectedProperties = dataTable.rawTable.slice(1);
  cy.get('@getResponse').its('body').then((responseBody) => {
    expectedProperties.forEach((property) => {
      const [key, value] = property;
      if (value === 'Array') {
        expect(responseBody[key]).to.be.an('array');
      } else {
        const parsedValue = JSON.parse(value);
        expect(responseBody[key]).to.deep.equal(parsedValue);
      }
    });
  });
});
